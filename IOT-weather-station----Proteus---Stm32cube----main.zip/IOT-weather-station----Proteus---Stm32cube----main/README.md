# IOT weather station  ( Proteus + Stm32cube ) 
 Circuit for IOT weather station implemented in proteus and Stm32cube
